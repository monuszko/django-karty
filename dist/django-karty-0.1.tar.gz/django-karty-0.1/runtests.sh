#! /bin/sh
coverage run manage.py test karty.tests
coverage report
